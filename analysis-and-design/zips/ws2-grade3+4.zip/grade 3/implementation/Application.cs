using System;
using System.Collections.Generic;
using System.Linq;

namespace MemberRegistry
{
    class Application
    {
        static void Main(string[] args)
        {
            persistance.IPersistance persistance = new persistance.JSONFilePersistance("saved.json");
            model.MemberLedger ledger = new model.MemberLedger(persistance);
			view.MainView view = new view.MainView();
			IEnumerable<controller.commands.BaseCommand> menu = PopulateMenu(view, ledger);
			controller.UserController controller = new controller.UserController(view, ledger, menu);

			controller.StartProgram();
        }

        static IEnumerable<controller.commands.BaseCommand> PopulateMenu(view.IView view, model.MemberLedger ledger)
        {
			List<controller.commands.BaseCommand> menu = new List<controller.commands.BaseCommand>();
			List<model.searchcriteria.ISearchCriteria> criteria = PopulateSearchCriteriaList();

			menu.Add(new controller.commands.ViewMemberCommand("View Member", view, ledger));
			menu.Add(new controller.commands.ListMembersCommand("List Members", view, ledger));
			menu.Add(new controller.commands.SearchCommand("Simple Search of Members", view, ledger, criteria));

			menu.Add(new controller.commands.AddMemberCommand("Create Member", view, ledger));
			menu.Add(new controller.commands.UpdateMemberCommand("Update Member", view, ledger));
			menu.Add(new controller.commands.DeleteMemberCommand("Delete Member", view, ledger));
			menu.Add(new controller.commands.AddBoatCommand("Add Boat", view, ledger));
			menu.Add(new controller.commands.UpdateBoatCommand("Update Boat", view, ledger));
			menu.Add(new controller.commands.DeleteBoatCommand("Delete Boat", view, ledger));

			menu.Add(new controller.commands.LogoutUserCommand("Logout User", view, ledger));
			menu.Add(new controller.commands.ExitProgramCommand("Exit Program", view, ledger));

			return menu;
        }

		public static List<model.searchcriteria.ISearchCriteria> PopulateSearchCriteriaList()
		{
			List<model.searchcriteria.ISearchCriteria> criteria = new List<model.searchcriteria.ISearchCriteria>();

			criteria.Add(new model.searchcriteria.HasCanoeCriteria());
			criteria.Add(new model.searchcriteria.StartsWithSCriteria());

			return criteria;
		}
    }
}