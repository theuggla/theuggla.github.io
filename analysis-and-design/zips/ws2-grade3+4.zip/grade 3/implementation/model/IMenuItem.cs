using System;
using System.Linq;
using System.Collections.Generic;

namespace MemberRegistry.model
{
    interface IMenuItem
    {
        string GetDescription();
    }
}