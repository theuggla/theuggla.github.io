Assumptions have been made in the development of the model, since the domain experts could in this case not be interviewed.

Assumptions made:
¤ The berths have different sizes that will affect the price of the berth.
¤ These sizes are not random, but rather divided into categories.
