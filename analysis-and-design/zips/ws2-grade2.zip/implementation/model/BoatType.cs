namespace MemberRegistry
{
    public enum BoatType
    {
        Sailboat,
        Motorsailer,
        Canoe,
        Other
    }
}